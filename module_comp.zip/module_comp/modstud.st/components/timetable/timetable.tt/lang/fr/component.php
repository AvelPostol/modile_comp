<?php
$MESS["CALENDAR_UPDATE_EVENT_WITH_LOCATION"] = "Conversion d'évènements";
$MESS["CALENDAR_UPDATE_STRUCTURE_TITLE"] = "Optimisation de la structure";
$MESS["EC_CALENDAR_INDEX"] = "Indexer les évènements du calendrier";
$MESS["EC_CALENDAR_NOT_PERMISSIONS_TO_VIEW_GRID_CONTENT"] = "Veuillez contacter votre administrateur Bitrix24 pour obtenir de l'aide";
$MESS["EC_CALENDAR_NOT_PERMISSIONS_TO_VIEW_GRID_TITLE"] = "L'accès au calendrier a été restreint par votre administrateur Bitrix24";
$MESS["EC_CALENDAR_SPOTLIGHT_LIST"] = "Basculez entre différents affichages du calendrier, selon votre convenance. Essayez notre nouvel affichage des Programmes pour les professionnels occupés qui ont besoin de voir en une liste tous leurs rendez-vous et toutes leurs réunions.";
$MESS["EC_CALENDAR_SPOTLIGHT_ROOMS"] = "Afficher les disponibilités de salle de réunion";
$MESS["EC_CALENDAR_SPOTLIGHT_SYNC"] = "Synchronisez automatiquement vos calendriers entre vos services et appareils mobiles. La synchronisation fonctionne dans les deux sens.";
$MESS["EC_GROUP_ID_NOT_FOUND"] = "Le calendrier du groupe ne peut pas être affiché. ID du groupe n'est pas indiqué.";
$MESS["EC_GROUP_NOT_FOUND"] = "Groupe introuvable.";
$MESS["EC_IBLOCK_ACCESS_DENIED"] = "Accès refusé";
$MESS["EC_IBLOCK_MODULE_NOT_INSTALLED"] = "Le module des blocs d'information n'a pas été installé.";
$MESS["EC_INTRANET_MODULE_NOT_INSTALLED"] = "Module du portail corporatif non installé.";
$MESS["EC_USER_ID_NOT_FOUND"] = "Le calendrier utilisateur ne peut pas être visualisé. L'ID utilisateur n'est pas indiqué.";
$MESS["EC_USER_NOT_FOUND"] = "L'utilisateur n'est pas trouvé.";
