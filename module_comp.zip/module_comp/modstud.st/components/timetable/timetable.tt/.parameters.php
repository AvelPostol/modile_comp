<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();


 $arComponentParameters = array(
"GROUPS" => array(),
"PARAMETERS" => array(
"TEMPLATE_FOR_DATE" => array(
"PARENT" => "BASE",
"NAME" => "Шаблон для таблица",
"TYPE" => "STRING",
"MULTIPLE" => "N",
"DEFAULT" => "Y-m-d",


),
),
);
