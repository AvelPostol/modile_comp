<?php
$MESS["CALENDAR_UPDATE_EVENT_WITH_LOCATION"] = "Convertendo eventos";
$MESS["CALENDAR_UPDATE_STRUCTURE_TITLE"] = "Otimizando estrutura";
$MESS["EC_CALENDAR_INDEX"] = "Índice de eventos do calendário";
$MESS["EC_CALENDAR_NOT_PERMISSIONS_TO_VIEW_GRID_CONTENT"] = "Por favor, entre em contato com seu administrador Bitrix24 para obter ajuda";
$MESS["EC_CALENDAR_NOT_PERMISSIONS_TO_VIEW_GRID_TITLE"] = "O acesso ao Calendário foi restrito pelo administrador do Bitrix24";
$MESS["EC_CALENDAR_SPOTLIGHT_LIST"] = "Alterne entre vários modos de exibição de calendário para sua conveniência. Experimente a nossa nova exibição da Programação, criada para profissionais ocupados, que precisam da exibição de uma lista de todas as reuniões e compromissos.";
$MESS["EC_CALENDAR_SPOTLIGHT_ROOMS"] = "Ver disponibilidade da sala de reunião";
$MESS["EC_CALENDAR_SPOTLIGHT_SYNC"] = "Sincronize seus calendários com outros serviços e dispositivos móveis automaticamente. A sincronização funciona nos dois sentidos.";
$MESS["EC_GROUP_ID_NOT_FOUND"] = "Não é possível mostrar o calendário do grupo porque o ID do grupo não foi especificado.";
$MESS["EC_GROUP_NOT_FOUND"] = "Grupo não foi encontrado.";
$MESS["EC_IBLOCK_ACCESS_DENIED"] = "Acesso negado";
$MESS["EC_IBLOCK_MODULE_NOT_INSTALLED"] = "O módulo \"blocos de informação\" não está instalado.";
$MESS["EC_INTRANET_MODULE_NOT_INSTALLED"] = "O módulo \"Portal Intranet\" não está instalado.";
$MESS["EC_USER_ID_NOT_FOUND"] = "Não é possível mostrar o calendário do usuário, pois o ID do usuário não foi especificado.";
$MESS["EC_USER_NOT_FOUND"] = "O usuário não foi encontrado.";
