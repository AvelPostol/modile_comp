<?
$MESS["EVENT_CALENDAR"] = "Calendrier d'évènements";
$MESS["EVENT_CALENDAR2"] = "Calendrier d'évènements 2.0";
$MESS["EVENT_CALENDAR_DESCRIPTION"] = "Composant pour l'affichage du calendrier d'évènements.";
?>