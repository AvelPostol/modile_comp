<?
$MESS["TASKS_MODULE_NOT_FOUND"] = "O módulo de tarefas não está instalado.";
?>