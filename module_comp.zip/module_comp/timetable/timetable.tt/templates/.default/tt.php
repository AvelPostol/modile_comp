<?
//представление компонента 
// читай - вывод структуры в шаблон

$APPLICATION->IncludeComponent(
"timetable:timetable.tt",
".default",
Array(
),
false
);


?>