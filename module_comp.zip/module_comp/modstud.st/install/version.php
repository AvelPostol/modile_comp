<?
$arModuleVersion = [
	"VERSION" => "0.0.1",
	"VERSION_DATE" => "11.04.2022"
];