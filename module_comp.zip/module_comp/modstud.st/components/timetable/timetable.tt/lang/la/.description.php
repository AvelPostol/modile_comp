<?
$MESS["EVENT_CALENDAR"] = "Calendario de eventos";
$MESS["EVENT_CALENDAR2"] = "Calendario de eventos 2.0";
$MESS["EVENT_CALENDAR_DESCRIPTION"] = "Un componente para visualizar el calendario de eventos.";
?>