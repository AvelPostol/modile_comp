<?
$MESS["EC_INTRANET_MODULE_NOT_INSTALLED"] = "Модуль корпоративный портал не установлен";
$MESS["EC_IBLOCK_MODULE_NOT_INSTALLED"] = "Модуль инфоблоков не установлен";
$MESS["EC_IBLOCK_ACCESS_DENIED"] = "Доступ запрещен";
$MESS["EC_USER_NOT_FOUND"] = "Пользователь не найден";
$MESS["EC_GROUP_NOT_FOUND"] = "Группа не найдена";
$MESS["EC_USER_ID_NOT_FOUND"] = "Календарь пользователя не может быть отображен. Не указан ID пользователя";
$MESS["EC_GROUP_ID_NOT_FOUND"] = "Календарь группы не может быть отображен. Не указан ID группы";
$MESS["EC_CALENDAR_INDEX"] = "Индексация событий календаря";
$MESS["EC_CALENDAR_SPOTLIGHT_SYNC"] = "Синхронизируйте ваши календари Битрикс24 с различными устройствами и сервисами, тем самым вы не пропустите важное событие или встречу!";
$MESS["EC_CALENDAR_SPOTLIGHT_LIST"] = "Переключайтесь между разными представлениями календаря и выберите наиболее удобный. \"Расписание\" позволяет просматривать все события ваших календарей в виде списка.";
$MESS["EC_CALENDAR_SPOTLIGHT_ROOMS"] = "Просматривайте занятость переговорных комнат в удобном формате";
$MESS["EC_CALENDAR_NOT_PERMISSIONS_TO_VIEW_GRID_TITLE"] = "Доступ к календарю ограничен администратором вашего Битрикс24";
$MESS["EC_CALENDAR_NOT_PERMISSIONS_TO_VIEW_GRID_CONTENT"] = "Обратитесь к администратору вашего Битрикс24";
$MESS["CALENDAR_UPDATE_EVENT_WITH_LOCATION"] = "Выполняется конвертация событий";
$MESS["CALENDAR_UPDATE_STRUCTURE_TITLE"] = "Выполняется оптимизация структуры";
?>
