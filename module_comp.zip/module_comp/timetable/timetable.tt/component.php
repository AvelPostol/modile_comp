<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();


use Bitrix\Main\Loader;

if(Loader::IncludeModule('modstud.st')){

  $STTable = \Modstud\St\StudTable::getList(array(
    'select' => array('*')
));
          
          /*
          $STTable = \Modstud\St\StudTable::getList([
            'select' => ['ID', 'NAME', 'SURNAME','PATRONYMIC'],
            'filter' => [],
          ]);
          $TEACHTable = \Modstud\St\TeachTable::getList([
            'select' => ['ID', 'NAME', 'SURNAME','PATRONYMIC'],
            'filter' => [],
          ]);
          $CATEGORYTable = \Modstud\St\CategoryTable::getList([
            'select' => ['ID', 'TABLE_ST_ID', 'ID_STUD'],
            'filter' => [],
          ]);*/

      }
 

$this->IncludeComponentTemplate();






?>