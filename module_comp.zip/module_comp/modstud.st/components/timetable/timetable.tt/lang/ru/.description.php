<?
$MESS["EVENT_CALENDAR"] = "Календарь событий";
$MESS["EVENT_CALENDAR2"] = "Календарь событий 2.0";
$MESS["EVENT_CALENDAR_DESCRIPTION"] = "Компонент для отображения календаря событий";
?>