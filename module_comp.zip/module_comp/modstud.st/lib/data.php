<?php
namespace Modstud\St;

use Bitrix\Main\Entity;
use Bitrix\Main\Localization\Loc;
 

 
class StudTable extends Entity\DataManager
{
	/**
	 * Returns DB table name for entity.
	 *
	 * @return string
	 */
	public static function getTableName()
	{
		return 'modstud_st';
	}

	/**
	 * Returns entity map definition.
	 *
	 * @return array
	 */
	public static function getMap()
	{
		return array(
			'ID' => array(
				'data_type' => 'integer',
				'primary' => true,
				'autocomplete' => true,
				'title' => Loc::getMessage('DATA_ENTITY_ID_FIELD'),
			),
			'NAME' => array(
				'data_type' => 'text',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_NAME_FIELD'),
			),
			'SURNAME' => array(
				'data_type' => 'text',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_SURNAME_FIELD'),
			),
			'PATRONYMIC' => array(
				'data_type' => 'text',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_PATR_FIELD'),
			),
		);
	}
}




class TeachTable extends Entity\DataManager
{
	/**
	 * Returns DB table name for entity.
	 *
	 * @return string
	 */
	public static function getTableName()
	{
		return 'modstud_teach';
	}

	/**
	 * Returns entity map definition.
	 *
	 * @return array
	 */
	public static function getMap()
	{
		return array(
			'ID' => array(
				'data_type' => 'integer',
				'primary' => true,
				'autocomplete' => true,
				'title' => Loc::getMessage('DATA_ENTITY_ID_FIELD'),
			),
			'NAME' => array(
				'data_type' => 'text',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_NAME_FIELD'),
			),
			'SURNAME' => array(
				'data_type' => 'text',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_SURNAME_FIELD'),
			),
			'PATRONYMIC' => array(
				'data_type' => 'text',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_PATR_FIELD'),
			),
		);
	}
}




class TimeTable extends Entity\DataManager
{
	/**
	 * Returns DB table name for entity.
	 *
	 * @return string
	 */
	public static function getTableName()
	{
		return 'modstud_tt';
	}

	/**
	 * Returns entity map definition.
	 *
	 * @return array
	 */
	public static function getMap()
	{
		return array(
			'ID' => array(
				'data_type' => 'integer',
				'primary' => true,
				'autocomplete' => true,
				'title' => Loc::getMessage('DATA_ENTITY_ID_FIELD'),
			),
			'DATETIME' => array(
				'data_type' => 'datetime',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_CREATED_FIELD'),
			),
			'ClASSROOM' => array(
				'data_type' => 'text',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_CLASSROOM'),
			),
			'LESSON' => array(
				'data_type' => 'text',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_LESSON'),
			),
			'ID_TEACH' => array(
				'data_type' => 'integer',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_TEACH'),
			),
			'TABLE_ST_ID' => array(
				'data_type' => 'integer',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_TABLE_ST_ID'),
			),
		);
	}
}





class CategoryTable extends Entity\DataManager
{
	/**
	 * Returns DB table name for entity.
	 *
	 * @return string
	 */
	public static function getTableName()
	{
		return 'modstud_category';
	}

	/**
	 * Returns entity map definition.
	 *
	 * @return array
	 */
	public static function getMap()
	{
		return array(
			'ID' => array(
				'data_type' => 'integer',
				'primary' => true,
				'autocomplete' => true,
				'title' => Loc::getMessage('DATA_ENTITY_ID_FIELD'),
			),
			'TABLE_ST_ID' => array(
				'data_type' => 'integer',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_TABLE_ST_ID'),
			),
			'ID_STUD' => array(
				'data_type' => 'integer',
				'required' => true,
				'title' => Loc::getMessage('DATA_ENTITY_ID_STUD'),
			),
		);
	}
}
