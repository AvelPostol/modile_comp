DROP TABLE IF EXISTS `modstud_st`;
DROP TABLE IF EXISTS `modstud_teach`;
DROP TABLE IF EXISTS `modstud_tt`;
DROP TABLE IF EXISTS `modstud_category`;