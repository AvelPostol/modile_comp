<?
$MESS["EVENT_CALENDAR2"] = "Event Calendar 2.0";
$MESS["EVENT_CALENDAR_DESCRIPTION"] = "A component to display the event calendar.";
$MESS["EVENT_CALENDAR"] = "Event Calendar";
?>