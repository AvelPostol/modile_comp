<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();



use Bitrix\Main\Loader;

if(CModule::IncludeModule('modstud.st')){

  $STTable = \Modstud\St\StudTable::getList(array(
    'select' => array('*')
));

      
?>


<table border="1">
   <caption><? $arComponentDescription["NAME"] ?></caption>
   <tr>
    <th></th><!--категории-->
   </tr>
   <tr><td></td></tr><!--пункты-->
   <tr><td></td></tr>
  </table>
<?

}

?>

