<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

/*
$arComponentDescription = array(
"NAME" => GetMessage("Таблица рассписания"),
"DESCRIPTION" => GetMessage("Выводим таблицу рас-я"),
"PATH" => array(
"ID" => "tt_components",
"CHILD" => array(
"ID" => "curtt",
"NAME" => "Таблица"
)
),
"ICON" => "/images/icon.gif",


);

/