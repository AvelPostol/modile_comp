<?
$MESS["EC_P_ALLOW_RES_MEETING"] = "Ativar sistema de reserva de sala de vídeo-conferência";
$MESS["EC_P_ALLOW_SUPERPOSE"] = "Usar calendários favoritos";
$MESS["EC_TYPE"] = "Tipo de calendário";
?>