<?
$MESS["TASKS_MODULE_NOT_FOUND"] = "El módulo de tareas no está instalado.";
?>