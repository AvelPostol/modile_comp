<?php
Bitrix\Main\Loader::registerAutoloadClasses(
	"modstud.st",
	array(
		"Modstud\\St\\StudTable" => "lib/StudTable.php",
		"Modstud\\St\\TeachTable" => "lib/StudTable.php",
		"Modstud\\St\\TimeTable" => "lib/StudTable.php",
		"Modstud\\St\\CategoryTable" => "lib/StudTable.php",
		
	)
);
