<?php
$MESS["CALENDAR_UPDATE_EVENT_WITH_LOCATION"] = "Converting events";
$MESS["CALENDAR_UPDATE_STRUCTURE_TITLE"] = "Optimizing structure";
$MESS["EC_CALENDAR_INDEX"] = "Index calendar events";
$MESS["EC_CALENDAR_NOT_PERMISSIONS_TO_VIEW_GRID_CONTENT"] = "Please contact your Bitrix24 administrator to get help";
$MESS["EC_CALENDAR_NOT_PERMISSIONS_TO_VIEW_GRID_TITLE"] = "Access to the Calendar was restricted by your Bitrix24 administrator";
$MESS["EC_CALENDAR_SPOTLIGHT_LIST"] = "Switch between various calendar views for your convenience. Try our new Schedule view created for busy professionals who need a list view of all meetings and appointments.";
$MESS["EC_CALENDAR_SPOTLIGHT_ROOMS"] = "View meeting room availability";
$MESS["EC_CALENDAR_SPOTLIGHT_SYNC"] = "Synchronize your calendars with other services and mobile devices automatically. The synchronization works both ways.";
$MESS["EC_GROUP_ID_NOT_FOUND"] = "Cannot show the group calendar because the group ID is not specified.";
$MESS["EC_GROUP_NOT_FOUND"] = "Group was not found.";
$MESS["EC_IBLOCK_ACCESS_DENIED"] = "Access denied";
$MESS["EC_IBLOCK_MODULE_NOT_INSTALLED"] = "The \"Information Blocks\" module is not installed.";
$MESS["EC_INTRANET_MODULE_NOT_INSTALLED"] = "The \"Intranet Portal\" module is not installed.";
$MESS["EC_USER_ID_NOT_FOUND"] = "Cannot show the user calendar because the user ID is not specified.";
$MESS["EC_USER_NOT_FOUND"] = "The user was not found.";
