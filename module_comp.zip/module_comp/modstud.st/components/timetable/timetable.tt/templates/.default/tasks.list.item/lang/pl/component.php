<?
$MESS["TASKS_MODULE_NOT_FOUND"] = "Moduł zadań nie jest zainstalowany.";
?>