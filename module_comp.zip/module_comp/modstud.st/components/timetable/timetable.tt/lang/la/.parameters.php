<?
$MESS["EC_P_ALLOW_RES_MEETING"] = "Habilitar la sala de reunión (video) sistema de reservas";
$MESS["EC_P_ALLOW_SUPERPOSE"] = "Utilizar calendarios Favoritos";
$MESS["EC_TYPE"] = "Tipo de calendario";
?>