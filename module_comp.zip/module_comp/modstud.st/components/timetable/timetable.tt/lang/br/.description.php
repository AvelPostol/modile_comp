<?
$MESS["EVENT_CALENDAR"] = "Calendário de Eventos";
$MESS["EVENT_CALENDAR2"] = "Calendário de eventos 2.0";
$MESS["EVENT_CALENDAR_DESCRIPTION"] = "Um componente para apresentar o calendário de eventos.";
?>