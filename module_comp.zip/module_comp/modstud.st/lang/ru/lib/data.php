<?
$MESS["DATA_ENTITY_ID_FIELD"] = "ID";
//тут особо не запаривался


