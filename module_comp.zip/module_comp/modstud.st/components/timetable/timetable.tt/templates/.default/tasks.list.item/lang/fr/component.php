<?
$MESS["TASKS_MODULE_NOT_FOUND"] = "Le module de commande des tâches n'a pas été installé.";
?>