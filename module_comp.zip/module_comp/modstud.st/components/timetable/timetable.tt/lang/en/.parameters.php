<?
$MESS["EC_TYPE"] = "Calendar type";
$MESS["EC_P_ALLOW_SUPERPOSE"] = "Use favorite calendars";
$MESS["EC_P_ALLOW_RES_MEETING"] = "Enable (video)meeting room booking system";
?>