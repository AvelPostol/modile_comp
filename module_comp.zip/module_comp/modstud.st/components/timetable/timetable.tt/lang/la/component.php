<?php
$MESS["CALENDAR_UPDATE_EVENT_WITH_LOCATION"] = "Conversión de eventos";
$MESS["CALENDAR_UPDATE_STRUCTURE_TITLE"] = "Optimización de la estructura";
$MESS["EC_CALENDAR_INDEX"] = "Ïndice de eventos del calendario";
$MESS["EC_CALENDAR_NOT_PERMISSIONS_TO_VIEW_GRID_CONTENT"] = "Póngase en contacto con su administrador de Bitrix24 para obtener ayuda";
$MESS["EC_CALENDAR_NOT_PERMISSIONS_TO_VIEW_GRID_TITLE"] = "El acceso al Calendario fue restringido por su administrador de Bitrix24";
$MESS["EC_CALENDAR_SPOTLIGHT_LIST"] = "Cambie entre varias vistas de calendario para su conveniencia. Pruebe nuestra nueva vista Programada creada para profesionales ocupados que necesitan una vista de lista de todas las reuniones y citas.";
$MESS["EC_CALENDAR_SPOTLIGHT_ROOMS"] = "Ver la disponibilidad de la sala de reuniones";
$MESS["EC_CALENDAR_SPOTLIGHT_SYNC"] = "Sincronice automáticamente sus calendarios con otros servicios y dispositivos móviles. La sincronización funciona en ambos sentidos.";
$MESS["EC_GROUP_ID_NOT_FOUND"] = "No se puede mostrar el calendario de grupo porque no se ha especificado el ID de grupo.";
$MESS["EC_GROUP_NOT_FOUND"] = "No se encontró el grupo.";
$MESS["EC_IBLOCK_ACCESS_DENIED"] = "Acceso denegado";
$MESS["EC_IBLOCK_MODULE_NOT_INSTALLED"] = "No está instalado el módulo de \"Bloques de información\".";
$MESS["EC_INTRANET_MODULE_NOT_INSTALLED"] = "No está instalado el módulo de \"Portal de Intranet\".";
$MESS["EC_USER_ID_NOT_FOUND"] = "No se puede mostrar el calendario de usuario porque no se ha especificado el ID del usuario.";
$MESS["EC_USER_NOT_FOUND"] = "Usuario no encontrado";
