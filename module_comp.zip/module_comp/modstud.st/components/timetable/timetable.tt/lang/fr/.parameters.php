<?
$MESS["EC_P_ALLOW_RES_MEETING"] = "Utiliser la possibilité de la réservation des salles de réunion/salles de visioconférences";
$MESS["EC_P_ALLOW_SUPERPOSE"] = "Autoriser l'utilisation de calendriers choisis";
$MESS["EC_TYPE"] = "Type de calendrier";
?>