<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();


$_SERVER["DOCUMENT_ROOT"] = "/home/bitrix/www";
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Loader;

if(CModule::IncludeModule('modstud.st')){


          $TimeTable = \Modstud\St\TimeTable::getList([
            'select' => ['ID', 'DATETIME', 'CLASSROOM','LESSON', 'ID_TEACH', 'TABLE_ST_ID'],
            'filter' => [],
          ]);
          $STTable = \Modstud\St\StudTable::getList([
            'select' => ['ID', 'NAME', 'SURNAME','PATRONYMIC'],
            'filter' => [],
          ]);
          $TEACHTable = \Modstud\St\TeachTable::getList([
            'select' => ['ID', 'NAME', 'SURNAME','PATRONYMIC'],
            'filter' => [],
          ]);
          $CATEGORYTable = \Modstud\St\CategoryTable::getList([
            'select' => ['ID', 'TABLE_ST_ID', 'ID_STUD'],
            'filter' => [],
          ]);

      }



$this->IncludeComponentTemplate();






?>