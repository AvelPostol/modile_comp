<?
$MESS["TASKS_MODULE_NOT_FOUND"] = "The Task module is not installed.";
?>